package com.example.buscaminas

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
